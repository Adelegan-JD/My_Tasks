# Price display with type casting
garri_price = (input("How much is Garri per paint currently ma?: "))   # This collects the price of Garri from the seller
price = float(garri_price)
print(f"The current price of Garri is {price} kobo. Thank you for your patronage. ")