FName = input("Kindly enter your first name here: ")  # This code requests for the name of the user
age = input("Kindly enter your age here: ")    # This code requests for the age of the user
print(f"Welcome {FName}, you are {age} years old")  # This displays the a welcome message with the name and the age of the user

